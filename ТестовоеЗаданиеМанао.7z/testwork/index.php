<?php


require_once('conf/core.php');


?>