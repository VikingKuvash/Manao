<?php

    class CabinetModel extends Model{
        
    }
?>