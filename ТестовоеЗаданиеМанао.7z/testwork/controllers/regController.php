<?php
     
class regController extends Controller {
      
    private $pageTpl = "/views/reg.tpl.php";

    public function __construct () {
        $this->model = new regModel();
        $this->view = new View ();
    }

    public function index (){
        $this->pageData['title'] = "Регистрация";
        if(!empty($_POST)){
            if(!$this->registrat()){
            }
       }
       $this->view->render($this->pageTpl, $this->pageData);
    }

    public function registrat(){
        /*
        if (mb_strlen($_POST['password']) < 6) 
            $this->pageData['error1'] = "Короткий пароль, символов должно быть больше 6";
        if($_POST['password'] != $_POST['password2'])
            $this->pageData['error'] = "Проверьте пароли,так как они не совпали.";
        if($_POST['login'] == trim($_POST['login']) && strpos($_POST['login'], ' ') !== false){
            $this->pageData['error'] = 'Пробелы, в начале или в конце';
        } 
       if(!empty($_POST) || !isset($_POST['login']) || !isset($_POST['password']) || !isset($_POST['password2']) || !isset($_POST['email']) || !isset($_POST['name'])){
            $login = trim($_POST['login']);
            $password = trim(md5($_POST['password']));
			$email = trim($_POST['email']);
            $name = trim($_POST['name']);
          $this->model->regNewUser($login,$password, $email,$name);
           return true;
        } else {
            $this->pageData['error'] = "Вы заполнили не все поля";
			return false;
        }
        *//*
        $login = filter_var(trim($_POST['login']), FILTER_SANITIZE_STRING);
        $password = filter_var(trim(md5($_POST['password'])), FILTER_SANITIZE_STRING);
        $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
        $name = filter_var(trim($_POST['name']), FILTER_SANITIZE_STRING);
        if (mb_strlen($login) < 5 || mb_strlen($login) > 10) {
            $this->pageData['registerMsg'] = "Недопустимая длина логина";
        }elseif (mb_strlen($password) < 5) {
            $this->pageData['registerMsg'] = "Короткий пароль, символов должно быть больше 5";
        }elseif ($_POST['password'] != $_POST['password2']) {
            $this->pageData['registerMsg'] = "Проверьте пароли,так как они не совпали.";
        }
        $this->model->regNewUser($login,$password, $email,$name);
     return false;*/
     if(isset($_POST)){
        $login = $_POST['login'];
        $password = md5($_POST['password']);
        $password2 = md5($_POST['password2']);
        $email = $_POST['email'];
        $name = $_POST['name'];
        
        $error = array();
        
        if(trim($login) == ''){
             $error[] = 'Введите логин';
         }

         if (!preg_match("/^\s*[^\s]+\s*$/", $login)) {
            $error [] = 'Ввод пробелов запрещен в логине';
         }   
        
         if(trim($password) == ''){
            $error[] = 'Введите пароль';
        }
        if(!preg_match("/^\s*[^\s]+\s*$/",$password)){
            $error [] = 'Ввод пробелов запрещен в пароле';
        }

        if($password != $password2){
            $error[] = 'Пароли не совпадают';
        }

        if(mb_strlen($_POST['password']) < 6){
            $error[] = 'Короткий пароль, символов должно быть больше 6';
        }

        if(empty($email))
         $error[] = 'Поле Email не может быть пустым!';
        else{
        if(!preg_match("/^[a-z0-9_.-]+@([a-z0-9]+\.)+[a-z]{2,6}$/i", $email))
         $error[] = 'Не правильно введен E-mail';
         }

         if(mb_strlen($_POST['name']) < 3){
            $error[] = 'Короткое имя, символов должно быть больше 3 символа';
        }
        if (!preg_match("/^\s*[^\s]+\s*$/", $name)) {
            $error [] = 'Ввод пробелов запрещен в имени';
         }  

        if(empty($error)){
            $this->model->regNewUser($login,$password, $email,$name);
            echo 'Регистрируем'. '<br>';
        } else {
           echo 'У вас такие ошибки:' . '<br>' .array_shift($error).'<br>';
        }

     }
        
    
    
    


    } // <---- конец функции

}




















?>