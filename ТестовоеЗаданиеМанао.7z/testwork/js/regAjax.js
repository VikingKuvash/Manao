$(document).ready(function(){
	$('#btn').click(function(){
		let arrayPost = {
			login : $('#login').val(),
			password = $('#password').val(),
			email = $('#email').val(),
			name = $('#name').val()
		};
		// let login = $('#login').val();
		// let password = $('#password').val();
		// let email = $('#email').val();
		// let name = $('#name').val();
		 	$.ajax ({
				url: "/Controller/regController.php", 
				type: "POST", 
              	dataType: "json",
				// data: { 
				// 	"login":   login,
				// 	"password":  password,
				// 	"email": email,
				// 	"name": name,
				// },
				data: arrayPost,
				success: function(data){
					$('.result').html(data.result); 
				//	event.preventDefault();
				}
		 });
	});
});

