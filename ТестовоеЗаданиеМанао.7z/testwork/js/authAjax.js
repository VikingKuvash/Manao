$(document).ready(function(){
	$('#btn').click(function(){
		let arrayPost = {
			login : $('#login').val(),
			password = $('#password').val(),
		};
		 	$.ajax ({
				url: "/Controller/IndexController.php", 
				type: "POST", 
              	dataType: "json",
				// data: { 
				// 	"login":   login,
				// 	"password":  password,
				// 	"email": email,
				// 	"name": name,
				// },
				data: arrayPost,
				success: function(data){
					$('.result').html(data.result); 
					event.preventDefault();
				}
		 });
	});
});

